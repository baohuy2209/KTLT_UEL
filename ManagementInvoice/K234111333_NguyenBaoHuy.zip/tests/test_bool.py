isFlag = bool("")
a = True
print(type(isFlag))
print(type(a))
print(isFlag)